
import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                               QHBoxLayout, QGridLayout, QPushButton, QLabel, 
                               QFrame, QTextEdit, QTabWidget)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtCore import QUrl, Qt, QTimer
from PySide6.QtGui import QFont, QPalette, QColor
from pathlib import Path
from datetime import datetime

#from tactical_drawing import TacticalDrawingTab
from tactical_drawing_icd import TacticalDrawingTab
# from backend import Backend
import subprocess


class COPDisplay(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("COP Multi-Functional Display System")
        self.setGeometry(100, 100, 1600, 1000)
        
        # Set dark theme
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QPushButton {
                background-color: #2a2a2a;
                color: #00ff00;
                border: 2px solid #00ff00;
                border-radius: 5px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #3a3a3a;
                border: 2px solid #00ff00;
            }
            QPushButton:pressed {
                background-color: #00ff00;
                color: #000000;
            }
            QPushButton#emergency {
                background-color: #8b0000;
                color: white;
                border: 2px solid #ff0000;
            }
            QPushButton#emergency:hover {
                background-color: #a00000;
            }
            QLabel {
                color: #00ff00;
                font-weight: bold;
            }
            QFrame {
                border: 2px solid #333333;
                background-color: #0a0a0a;
            }
            QTextEdit {
                background-color: #000000;
                color: #00ff00;
                border: none;
                font-family: 'Courier New';
                font-size: 10px;
            }
            QTabWidget::pane {
                border: 2px solid #333333;
                background-color: #0a0a0a;
            }
            QTabBar::tab {
                background-color: #2a2a2a;
                color: #00ff00;
                border: 2px solid #00ff00;
                padding: 10px 20px;
                margin-right: 5px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background-color: #00ff00;
                color: #000000;
            }
            QTabBar::tab:hover {
                background-color: #3a3a3a;
            }
        """)
        
        # Map zoom and pan variables
        self.zoom_level = 12
        self.map_center = [28.6139, 77.2090]
        self.fullscreen_mode = False
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(10)
        
        # Header
        header_layout = self.create_header()
        main_layout.addLayout(header_layout)
        
        # Tab widget
        self.tab_widget = QTabWidget()
        
        # Create tabs
        self.cop_tab = self.create_cop_tab()
        self.drawing_tab = TacticalDrawingTab()
        
        self.tab_widget.addTab(self.cop_tab, "🗺 COP DISPLAY")
        self.tab_widget.addTab(self.drawing_tab, "✏ TACTICAL DRAWING")
        
        main_layout.addWidget(self.tab_widget)
        
        # Initialize timer for updates
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_displays)

    def create_header(self):
        """Create header layout"""
        header_layout = QHBoxLayout()
        
        title_label = QLabel("COMMON OPERATING PICTURE - MULTI-FUNCTIONAL DISPLAY")
        title_label.setStyleSheet("color: #00ff00; font-size: 16px; font-weight: bold;")
        header_layout.addWidget(title_label)
        
        header_layout.addStretch()
        
        self.status_label = QLabel("● OPERATIONAL")
        self.status_label.setStyleSheet("color: #00ff00; font-size: 14px; font-weight: bold;")
        header_layout.addWidget(self.status_label)
        
        return header_layout

    def create_cop_tab(self):
        """Create the original COP display tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        
        # Control buttons row
        controls_layout = QHBoxLayout()
        controls_layout.setSpacing(5)
        
        # Zoom and navigation buttons
        btn_zoom_in = QPushButton("ZOOM IN")
        btn_zoom_in.clicked.connect(self.zoom_in)
        controls_layout.addWidget(btn_zoom_in)
        
        btn_zoom_out = QPushButton("ZOOM OUT")
        btn_zoom_out.clicked.connect(self.zoom_out)
        controls_layout.addWidget(btn_zoom_out)
        
        controls_layout.addWidget(QLabel("|"))
        
        btn_north = QPushButton("↑ N")
        btn_north.clicked.connect(self.pan_north)
        controls_layout.addWidget(btn_north)
        
        btn_south = QPushButton("↓ S")
        btn_south.clicked.connect(self.pan_south)
        controls_layout.addWidget(btn_south)
        
        btn_east = QPushButton("→ E")
        btn_east.clicked.connect(self.pan_east)
        controls_layout.addWidget(btn_east)
        
        btn_west = QPushButton("← W")
        btn_west.clicked.connect(self.pan_west)
        controls_layout.addWidget(btn_west)
        
        controls_layout.addWidget(QLabel("|"))
        
        btn_center = QPushButton("CENTER")
        btn_center.clicked.connect(self.center_map)
        controls_layout.addWidget(btn_center)
        
        btn_fullscreen = QPushButton("FULLSCREEN MAP")
        btn_fullscreen.clicked.connect(self.toggle_fullscreen)
        controls_layout.addWidget(btn_fullscreen)
        self.btn_fullscreen = btn_fullscreen
        
        controls_layout.addStretch()
        
        btn_emergency = QPushButton("EMERGENCY")
        btn_emergency.setObjectName("emergency")
        btn_emergency.clicked.connect(self.emergency_alert)
        controls_layout.addWidget(btn_emergency)
        
        layout.addLayout(controls_layout)
        
        # Display panels container
        panels_frame = QFrame()
        panels_layout = QGridLayout(panels_frame)
        panels_layout.setContentsMargins(10, 10, 10, 10)
        panels_layout.setSpacing(10)
        
        # Top-left: Tactical Map
        self.tactical_map_frame = self.create_panel_frame("Tactical Map")
        self.create_tactical_map(self.tactical_map_frame)
        panels_layout.addWidget(self.tactical_map_frame, 0, 0)
        
        # Top-right: Threat Radar
        self.threat_radar_frame = self.create_panel_frame("Threat Radar")
        self.create_threat_radar(self.threat_radar_frame)
        panels_layout.addWidget(self.threat_radar_frame, 0, 1)
        
        # Bottom-left: Flight & Systems
        self.flight_systems_frame = self.create_panel_frame("Flight & Systems")
        self.create_flight_systems(self.flight_systems_frame)
        panels_layout.addWidget(self.flight_systems_frame, 1, 0)
        
        # Bottom-right: Event Log
        self.event_log_frame = self.create_panel_frame("Event Log")
        self.create_event_log(self.event_log_frame)
        panels_layout.addWidget(self.event_log_frame, 1, 1)
        
        # Store the panels layout for fullscreen toggle
        self.panels_layout = panels_layout
        
        layout.addWidget(panels_frame)
        
        return tab
        
    def create_panel_frame(self, title):
        """Create a frame with title for each panel"""
        frame = QFrame()
        frame.setFrameStyle(QFrame.Box)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(5, 5, 5, 5)
        
        title_label = QLabel(title)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("color: #00ff00; font-size: 13px; font-weight: bold; border: none;")
        layout.addWidget(title_label)
        
        return frame
    
    def create_tactical_map(self, parent_frame):
        layout = parent_frame.layout()

        self.map_view = QWebEngineView()
        self.map_view.setUrl(QUrl("http://127.0.0.1:5000"))

        layout.addWidget(self.map_view)
    
    def create_threat_radar(self, parent_frame):
        """Create threat radar display"""
        layout = parent_frame.layout()
        
        radar_view = QWebEngineView()
        html_content = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { 
                    margin: 0; 
                    background: #000; 
                    color: #0f0; 
                    font-family: monospace;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    height: 100vh;
                }
                .radar {
                    position: relative;
                    width: 300px;
                    height: 300px;
                }
                .radar-circle {
                    position: absolute;
                    border: 2px solid #0f0;
                    border-radius: 50%;
                    opacity: 0.5;
                }
                .sweep {
                    position: absolute;
                    width: 2px;
                    height: 150px;
                    background: #0f0;
                    top: 150px;
                    left: 150px;
                    transform-origin: top center;
                    animation: sweep 4s linear infinite;
                }
                @keyframes sweep {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                .threat {
                    position: absolute;
                    width: 8px;
                    height: 8px;
                    background: #ff0;
                    border-radius: 50%;
                    animation: blink 1s ease-in-out infinite;
                }
                @keyframes blink {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.3; }
                }
                .center-dot {
                    position: absolute;
                    width: 6px;
                    height: 6px;
                    background: #0f0;
                    border-radius: 50%;
                    top: 147px;
                    left: 147px;
                }
            </style>
        </head>
        <body>
            <div class="radar">
                <div class="radar-circle" style="width: 300px; height: 300px; top: 0; left: 0;"></div>
                <div class="radar-circle" style="width: 200px; height: 200px; top: 50px; left: 50px;"></div>
                <div class="radar-circle" style="width: 100px; height: 100px; top: 100px; left: 100px;"></div>
                <div class="sweep"></div>
                <div class="center-dot"></div>
                <div class="threat" style="top: 80px; left: 180px;"></div>
                <div class="threat" style="top: 200px; left: 240px;"></div>
                <div class="threat" style="top: 130px; left: 90px;"></div>
            </div>
        </body>
        </html>
        """
        radar_view.setHtml(html_content)
        layout.addWidget(radar_view)
    
    def create_flight_systems(self, parent_frame):
        """Create flight and systems status display"""
        layout = parent_frame.layout()
        
        systems_view = QWebEngineView()
        html_content = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { 
                    margin: 0; 
                    padding: 20px;
                    background: #000; 
                    color: #0f0; 
                    font-family: 'Courier New', monospace;
                    font-size: 12px;
                }
                .status-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 15px;
                }
                .status-item {
                    border: 1px solid #0f0;
                    padding: 10px;
                    border-radius: 3px;
                }
                .label {
                    color: #888;
                    font-size: 10px;
                    margin-bottom: 5px;
                }
                .value {
                    font-size: 16px;
                    font-weight: bold;
                }
                .ok { color: #0f0; }
                .warn { color: #ff0; }
                .critical { color: #f00; }
            </style>
        </head>
        <body>
            <div class="status-grid">
                <div class="status-item">
                    <div class="label">ALTITUDE</div>
                    <div class="value ok">15,000 FT</div>
                </div>
                <div class="status-item">
                    <div class="label">SPEED</div>
                    <div class="value ok">420 KTS</div>
                </div>
                <div class="status-item">
                    <div class="label">HEADING</div>
                    <div class="value ok">285°</div>
                </div>
                <div class="status-item">
                    <div class="label">FUEL</div>
                    <div class="value ok">68%</div>
                </div>
                <div class="status-item">
                    <div class="label">ENGINE 1</div>
                    <div class="value ok">NOMINAL</div>
                </div>
                <div class="status-item">
                    <div class="label">ENGINE 2</div>
                    <div class="value ok">NOMINAL</div>
                </div>
                <div class="status-item">
                    <div class="label">HYDRAULICS</div>
                    <div class="value ok">NORMAL</div>
                </div>
                <div class="status-item">
                    <div class="label">AVIONICS</div>
                    <div class="value ok">ONLINE</div>
                </div>
            </div>
        </body>
        </html>
        """
        systems_view.setHtml(html_content)
        layout.addWidget(systems_view)
    
    def create_event_log(self, parent_frame):
        """Create event log display"""
        layout = parent_frame.layout()
        
        self.event_log = QTextEdit()
        self.event_log.setReadOnly(True)
        
        # Add initial events
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.event_log.append(f"[{timestamp}] INFO: System initialized")
        self.event_log.append(f"[{timestamp}] INFO: All systems operational")
        self.event_log.append(f"[{timestamp}] INFO: Tactical map loaded")
        self.event_log.append(f"[{timestamp}] INFO: Threat radar active")
        
        layout.addWidget(self.event_log)
    
    def log_event(self, message, level="INFO"):
        """Add an event to the log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.event_log.append(f"[{timestamp}] {level}: {message}")
        # Auto-scroll to bottom
        self.event_log.verticalScrollBar().setValue(
            self.event_log.verticalScrollBar().maximum()
        )
    
    # Button handler methods
    def zoom_in(self):
        self.zoom_level += 1
        self.map_view.page().runJavaScript("if(typeof window.zoomIn === 'function') window.zoomIn();")
        self.update_map_info()
        self.log_event(f"Zoom level increased to {self.zoom_level}")
        
    def zoom_out(self):
        if self.zoom_level > 1:
            self.zoom_level -= 1
            self.map_view.page().runJavaScript("if(typeof window.zoomOut === 'function') window.zoomOut();")
            self.update_map_info()
            self.log_event(f"Zoom level decreased to {self.zoom_level}")
    
    def pan_north(self):
        self.map_view.page().runJavaScript("if(typeof window.panNorth === 'function') window.panNorth();")
        self.update_map_info()
        self.log_event("Map panned north")
    
    def pan_south(self):
        self.map_view.page().runJavaScript("if(typeof window.panSouth === 'function') window.panSouth();")
        self.update_map_info()
        self.log_event("Map panned south")
    
    def pan_east(self):
        self.map_view.page().runJavaScript("if(typeof window.panEast === 'function') window.panEast();")
        self.update_map_info()
        self.log_event("Map panned east")
    
    def pan_west(self):
        self.map_view.page().runJavaScript("if(typeof window.panWest === 'function') window.panWest();")
        self.update_map_info()
        self.log_event("Map panned west")
    
    def center_map(self):
        self.map_center = [28.6139, 77.2090]
        self.map_view.page().runJavaScript("if(typeof window.centerMap === 'function') window.centerMap();")
        self.update_map_info()
        self.log_event("Map centered to home position")
    
    def update_map_info(self):
        self.map_view.page().runJavaScript(
            "if(typeof window.getMapInfo === 'function') window.getMapInfo();"
        )
    
    def emergency_alert(self):
        self.status_label.setText("⚠ EMERGENCY")
        self.status_label.setStyleSheet("color: #ff0000; font-size: 14px; font-weight: bold;")
        self.log_event("EMERGENCY ALERT ACTIVATED", "CRITICAL")
        
        # Reset after 5 seconds
        QTimer.singleShot(5000, self.reset_status)
    
    def reset_status(self):
        self.status_label.setText("● OPERATIONAL")
        self.status_label.setStyleSheet("color: #00ff00; font-size: 14px; font-weight: bold;")
        self.log_event("System status reset to operational")
    
    def toggle_fullscreen(self):
        """Toggle map fullscreen mode"""
        if not self.fullscreen_mode:
            # Enter fullscreen - map takes all 4 sections
            self.fullscreen_mode = True
            self.btn_fullscreen.setText("EXIT FULLSCREEN")
            
            # Hide other panels
            self.threat_radar_frame.hide()
            self.flight_systems_frame.hide()
            self.event_log_frame.hide()
            
            # Make map span all grid cells
            self.panels_layout.addWidget(self.tactical_map_frame, 0, 0, 2, 2)
            
            self.log_event("Map fullscreen mode activated")
        else:
            # Exit fullscreen - restore original layout
            self.fullscreen_mode = False
            self.btn_fullscreen.setText("FULLSCREEN MAP")
            
            # Restore original positions
            self.panels_layout.addWidget(self.tactical_map_frame, 0, 0)
            self.threat_radar_frame.show()
            self.flight_systems_frame.show()
            self.event_log_frame.show()
            
            self.log_event("Map fullscreen mode deactivated")
    
    def update_displays(self):
        """Periodic update for dynamic displays"""
        pass  # Can be used for real-time data updates


def main():
    app = QApplication(sys.argv)
    
    # Start Flask server
    subprocess.Popen(["python", "tileserver.py"])

    # Set application-wide font
    font = QFont("Consolas", 10)
    app.setFont(font)

    window = COPDisplay()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()



