"""
ICD-Compliant Socket Sender
Sends aircraft/track data via UDP with proper message structure
Header (16 bytes) + Payload (40 bytes) = 56 bytes total
Transmission rate: 50Hz (20ms intervals)
"""
import socket
import struct
import time
import threading
import random
import math
from datetime import datetime


class ICDSocketSender:
    """Sends tactical data via UDP using ICD message structure"""
    
    def __init__(self, host='127.0.0.1', port=5001):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.running = False
        self.send_thread = None
        self.data_queue = []
        self.lock = threading.Lock()
        
        # Message counter (0-255, wraps around)
        self.message_counter = 0
        
        # ICD version
        self.icd_version_major = 1
        self.icd_version_minor = 0
        
    def start(self):
        """Start sending thread at 50Hz"""
        self.running = True
        self.send_thread = threading.Thread(target=self._send_loop, daemon=True)
        self.send_thread.start()
        print(f"ICD Socket Sender started on {self.host}:{self.port} @ 50Hz")
        
    def stop(self):
        """Stop sending thread"""
        self.running = False
        if self.send_thread:
            self.send_thread.join(timeout=1.0)
        print("ICD Socket Sender stopped")
    
    def update_data(self, aircraft_data):
        """Update data to be sent (called from main thread)"""
        with self.lock:
            if isinstance(aircraft_data, list):
                self.data_queue = aircraft_data.copy()
                #for log
                print(self.data_queue)
            else:
                self.data_queue = [aircraft_data]
    
    def _send_loop(self):
        """Sending loop - runs at 50Hz (20ms intervals)"""
        while self.running:
            start_time = time.time()
            
            with self.lock:
                data_to_send = self.data_queue.copy()
            
            if data_to_send:
                for aircraft in data_to_send:
                    try:
                        self._send_aircraft_icd(aircraft)
                    except Exception as e:
                        print(f"Error sending ICD packet: {e}")
            
            # Maintain 50Hz rate (20ms period)
            elapsed = time.time() - start_time
            sleep_time = max(0, 0.020 - elapsed)  # 20ms = 50Hz
            time.sleep(sleep_time)
    
    def _send_aircraft_icd(self, aircraft_data):
        """Send single aircraft data packet using ICD structure"""
        if not isinstance(aircraft_data, dict):
            return
        
        # Build ICD packet: Header (16 bytes) + Payload (40 bytes)
        packet = self._build_icd_packet(aircraft_data)
        
        # Send via UDP
        self.socket.sendto(packet, (self.host, self.port))
    
    def _build_icd_packet(self, data):
        """Build ICD-compliant packet structure"""
        # ==================== HEADER (16 bytes) ====================
        
        # Message counter (1 byte, 0-255, wraps around)
        message_counter = self.message_counter
        self.message_counter = (self.message_counter + 1) % 256#Because:uint8 max = 255
        
        # Opcode (1 byte, 1-99 for MC->NCO)
        opcode = 1  # Own aircraft position message
        
        # ICD version (2 bytes)
        icd_major = self.icd_version_major
        icd_minor = self.icd_version_minor
        
        # Payload size (4 bytes)
        payload_size = 40  # Fixed payload size
        
        # Timestamp (8 bytes, epoch with millisecond resolution)
        timestamp_ms = int(time.time() * 1000)  # Milliseconds since epoch
        
        # Pack header (16 bytes total)
        # Format: B B B B I Q
        # B = unsigned char (1 byte) x4
        # I = unsigned int (4 bytes)
        # Q = unsigned long long (8 bytes)
        header = struct.pack('!BBBBIQ',
            message_counter,      # 1 byte
            opcode,              # 1 byte
            icd_major,           # 1 byte
            icd_minor,           # 1 byte
            payload_size,        # 4 bytes
            timestamp_ms         # 8 bytes
        )
        
        # ==================== PAYLOAD (40 bytes) ====================
        
        # Extract aircraft data
        lat = data.get('lat', 0.0)
        lon = data.get('lon', 0.0)
        speed_kts = data.get('speed', 0.0)
        altitude_ft = data.get('alt', 0.0)
        heading = data.get('heading', 0.0)
        
        # Calculate derived parameters
        roll = self._calculate_roll(data)
        pitch = self._calculate_pitch(data)
        true_heading = heading  # Use provided heading
        
        # Calculate velocities in ECEF (NED frame)
        vel_n, vel_e, vel_u = self._calculate_velocities(speed_kts, heading, pitch)
        
        # Calculate other parameters
        mach = self._calculate_mach(speed_kts, altitude_ft)
        true_aoa = self._calculate_aoa(pitch, speed_kts)
        ground_speed = speed_kts  # Ground speed in knots
        
        # Random FOM values (Figure of Merit)
        pos_error_h = random.randint(1, 5)  # 1-5 for reasonable accuracy
        pos_error_v = random.randint(1, 5)
        
        # Valid flags (16 bits) - all parameters valid
        # Bit 15: pitch/roll, 14: true heading, 12: velocity, 11: pos error
        # 10: altitude, 9: pos error vertical, 8: satellite time, 7: true AoA
        # 6: mach, 5: baro alt, 4: ground speed
        valid_flags = 0xFFFF  # All bits set = all data valid
        
        # Convert values to ICD scaled integers
        # Use proper signed/unsigned ranges and clamp values to avoid
        # struct.pack errors (e.g. 'h' requires -32768..32767)

        def clamp_int(val, minv, maxv):
            try:
                ival = int(round(val))
            except Exception:
                ival = int(val)
            if ival < minv:
                return minv
            if ival > maxv:
                return maxv
            return ival

        # Roll, Pitch, True Heading: scaled to signed 16-bit , resol:0.0054932
        roll_scaled = clamp_int(roll / 0.0054932, -32768, 32767)
        pitch_scaled = clamp_int(pitch / 0.0054932, -32768, 32767)
        heading_scaled = clamp_int(true_heading / 0.0054932, -32768, 32767)

        # Velocities: signed 32-bit for N/E, signed 16-bit for Up,int32 min = -2,147,483,648, max =  2,147,483,647
        vel_n_scaled = clamp_int(vel_n / 0.00000116272, -2147483648, 2147483647)
        vel_e_scaled = clamp_int(vel_e / 0.00000116272, -2147483648, 2147483647)
        vel_u_scaled = clamp_int(vel_u / 0.03662221137119663, -32768, 32767)

        # Hybrid altitude: unsigned 16-bit
        altitude_m = altitude_ft * 0.3048  # Convert feet to meters
        altitude_scaled = clamp_int(altitude_m / 1.2912, 0, 0xFFFF)

        # Lat/Lon: signed 32-bit
        lat_scaled = clamp_int(lat / 0.000000083819, -2147483648, 2147483647)
        lon_scaled = clamp_int(lon / 0.0000000838190317, -2147483648, 2147483647)

        # Mach: unsigned 16-bit
        mach_scaled = clamp_int(mach / 0.00012207, 0, 0xFFFF)

        # True AoA: signed 16-bit
        aoa_scaled = clamp_int(true_aoa / 0.0054932, -32768, 32767)

        # Ground speed: unsigned 16-bit
        ground_speed_scaled = clamp_int(ground_speed / 0.0625, 0, 0xFFFF)

        # Baro inertial altitude: signed 16-bit (pack uses 'h')
        baro_alt_scaled = clamp_int(altitude_ft / 2.5, -32768, 32767)
        
        # Data type: 2 = GPS and INU
        data_type = 2
        
        # Reserved byte for alignment
        reserved = 0
        
        # Pack payload (40 bytes total)
        # Format: H h h h i i h H i i B B H h H h B B
        payload = struct.pack('!HhhhiihHiiBBHhHhBB',
            valid_flags,          # 2 bytes (0-1)
            roll_scaled,          # 2 bytes (2-3)
            pitch_scaled,         # 2 bytes (4-5)
            heading_scaled,       # 2 bytes (6-7)
            vel_n_scaled,         # 4 bytes (8-11)
            vel_e_scaled,         # 4 bytes (12-15)
            vel_u_scaled,         # 2 bytes (16-17)
            altitude_scaled,      # 2 bytes (18-19)
            lat_scaled,           # 4 bytes (20-23)
            lon_scaled,           # 4 bytes (24-27)
            pos_error_h,          # 1 byte (28)
            pos_error_v,          # 1 byte (29)
            mach_scaled,          # 2 bytes (30-31)
            aoa_scaled,           # 2 bytes (32-33)
            ground_speed_scaled,  # 2 bytes (34-35)
            baro_alt_scaled,      # 2 bytes (36-37)
            data_type,            # 1 byte (38)
            reserved              # 1 byte (39)
        )
        
        # Combine header and payload
        full_packet = header + payload
        
        return full_packet
    
    # ==================== CALCULATION FUNCTIONS ====================
    
    def _calculate_roll(self, data):
        """Calculate roll angle (simplified)"""
        ''' working
        # In real COP: derived from INS/INU
        # Here: simulate based on turn rate
        heading = data.get('heading', 0.0)
        speed = data.get('speed', 0.0)
        
        # Simulate roll during turns (simplified)
        roll = random.uniform(-5, 5)  # Small random roll
        '''
        heading = data.get('heading', 0.0) 
        speed = data.get('speed', 0.0)
         # Initialize previous heading if not exists
        if not hasattr(self, "_prev_heading"):
            self._prev_heading = heading

        # Calculate turn rate (deg/update)
        turn_rate = heading - self._prev_heading
        self._prev_heading = heading

        # Normalize wraparound
        if turn_rate > 180:
            turn_rate -= 360
        elif turn_rate < -180:
            turn_rate += 360

        # Simple roll model
        roll = turn_rate * speed * 0.05

        # Limit roll
        roll = max(min(roll, 30), -30)
        return roll
    
    def _calculate_pitch(self, data):
        """Calculate pitch angle"""
        # In real COP: from INS/INU
        # Here: simulate based on climb/descent
        altitude = data.get('alt', 15000)
        
        # Simulate pitch (level flight mostly)
        if altitude < 10000:
            pitch = random.uniform(-2, 8)  # Climbing
        elif altitude > 30000:
            pitch = random.uniform(-8, 2)  # Descending
        else:
            pitch = random.uniform(-3, 3)  # Level
        
        return pitch
    
    def _calculate_velocities(self, speed_kts, heading, pitch):
        """Calculate velocity components in NED frame"""
        # Convert speed from knots to m/s
        speed_ms = speed_kts * 0.514444
        
        # Convert heading to radians
        heading_rad = math.radians(heading)
        pitch_rad = math.radians(pitch)
        
        # Calculate velocity components
        # North velocity
        vel_n = speed_ms * math.cos(heading_rad) * math.cos(pitch_rad)
        
        # East velocity
        vel_e = speed_ms * math.sin(heading_rad) * math.cos(pitch_rad)
        
        # Up velocity (vertical)
        vel_u = speed_ms * math.sin(pitch_rad)
        
        return vel_n, vel_e, vel_u
    
    def _calculate_mach(self, speed_kts, altitude_ft):
        """Calculate Mach number"""
        # Speed of sound decreases with altitude
        # At sea level: ~661 kts
        # At 35000 ft: ~573 kts
        
        # Approximate speed of sound at altitude
        if altitude_ft < 36000:
            temp_c = 15.0 - (1.98 * altitude_ft / 1000)  # Standard atmosphere
        else:
            temp_c = -56.5  # Stratosphere
        
        speed_of_sound_ms = 331.3 + (0.606 * temp_c)
        speed_of_sound_kts = speed_of_sound_ms * 1.94384
        
        # Calculate Mach
        mach = speed_kts / speed_of_sound_kts
        
        return max(0.0, min(4.0, mach))  # Clamp to 0-4
    
    def _calculate_aoa(self, pitch, speed_kts):
        """Calculate angle of attack"""
        # In real COP: from air data system
        # Here: approximate based on pitch and speed
        
        # At high speed, AoA is small
        # At low speed, AoA increases
        
        if speed_kts > 400:
            aoa = pitch * 0.3  # Small AoA at high speed
        elif speed_kts > 250:
            aoa = pitch * 0.5
        else:
            aoa = pitch * 0.8  # Higher AoA at low speed
        
        # Add some noise
        aoa += random.uniform(-1, 1)
        
        return max(-90, min(90, aoa))  # Clamp to -90 to 90 deg


class ICDSocketReceiver:
    """Receives and decodes ICD messages (for testing)"""
    
    def __init__(self, host='0.0.0.0', port=5001):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((host, port))
        self.socket.setblocking(False)
        self.running = False
        self.receive_thread = None
        self.callback = None
        
    def start(self, callback=None):
        """Start receiving thread"""
        self.callback = callback
        self.running = True
        self.receive_thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.receive_thread.start()
        print(f"ICD Receiver listening on {self.host}:{self.port}")
        
    def stop(self):
        """Stop receiving thread"""
        self.running = False
        if self.receive_thread:
            self.receive_thread.join(timeout=1.0)
    
    def _receive_loop(self):
        """Receiving loop"""
        while self.running:
            try:
                data, addr = self.socket.recvfrom(4096)
                decoded = self._decode_icd_packet(data)
                
                if self.callback and decoded:
                    self.callback(decoded)
                elif decoded:
                    self._print_decoded(decoded)
                    
            except BlockingIOError:
                time.sleep(0.01)
            except Exception as e:
                print(f"Error receiving: {e}")
    
    def _decode_icd_packet(self, packet):
        """Decode ICD packet"""
        try:
            if len(packet) < 56:
                return None
            
            # Decode header (16 bytes)
            header_data = struct.unpack('!BBBBIQ', packet[0:16])
            msg_counter, opcode, icd_major, icd_minor, payload_size, timestamp_ms = header_data
            
            # Decode payload (40 bytes)
            payload_data = struct.unpack('!HhhhiihHiiBBHhHhBB', packet[16:56])
            
            (valid_flags, roll_raw, pitch_raw, heading_raw,
             vel_n_raw, vel_e_raw, vel_u_raw, alt_raw,
             lat_raw, lon_raw, pos_err_h, pos_err_v,
             mach_raw, aoa_raw, gs_raw, baro_alt_raw,
             data_type, reserved) = payload_data
            
            # Convert scaled values back to real units
            roll = roll_raw * 0.0054932
            pitch = pitch_raw * 0.0054932
            heading = heading_raw * 0.0054932
            
            vel_n = vel_n_raw * 0.00000116272
            vel_e = vel_e_raw * 0.00000116272
            vel_u = vel_u_raw * 0.00000116272
            
            altitude_m = alt_raw * 1.2912
            lat = lat_raw * 8.3819e-8
            lon = lon_raw * 8.3819e-8
            
            mach = mach_raw * 1.2207e-4
            aoa = aoa_raw * 0.0054932
            ground_speed = gs_raw * 0.0625
            baro_alt_ft = baro_alt_raw * 2.5
            
            return {
                'header': {
                    'msg_counter': msg_counter,
                    'opcode': opcode,
                    'icd_version': f"{icd_major}.{icd_minor}",
                    'timestamp_ms': timestamp_ms
                },
                'payload': {
                    'valid_flags': hex(valid_flags),
                    'roll': roll,
                    'pitch': pitch,
                    'heading': heading,
                    'vel_n': vel_n,
                    'vel_e': vel_e,
                    'vel_u': vel_u,
                    'altitude_m': altitude_m,
                    'lat': lat,
                    'lon': lon,
                    'pos_error_h': pos_err_h,
                    'pos_error_v': pos_err_v,
                    'mach': mach,
                    'aoa': aoa,
                    'ground_speed': ground_speed,
                    'baro_alt_ft': baro_alt_ft,
                    'data_type': data_type
                }
            }
            
        except Exception as e:
            print(f"Error decoding packet: {e}")
            return None
    
    def _print_decoded(self, decoded):
        """Print decoded message"""
        h = decoded['header']
        p = decoded['payload']
        
        print(f"\n[Msg #{h['msg_counter']}] Opcode: {h['opcode']} | ICD: {h['icd_version']}")
        print(f"  Position: {p['lat']:.6f}°, {p['lon']:.6f}° | Alt: {p['altitude_m']:.1f}m")
        print(f"  Heading: {p['heading']:.1f}° | Pitch: {p['pitch']:.2f}° | Roll: {p['roll']:.2f}°")
        print(f"  Speed: {p['ground_speed']:.1f}kts | Mach: {p['mach']:.3f} | AoA: {p['aoa']:.2f}°")
        print(f"  Velocity: N={p['vel_n']:.2f} E={p['vel_e']:.2f} U={p['vel_u']:.2f} m/s")


# For backward compatibility
SocketSender = ICDSocketSender


# Test receiver
if __name__ == "__main__":
    print("=" * 60)
    print("ICD SOCKET RECEIVER TEST")
    print("=" * 60)
    print(f"Message Structure: Header (16B) + Payload (40B) = 56B")
    print(f"Receiving on 0.0.0.0:5001 @ 50Hz")
    print("=" * 60)
    
    receiver = ICDSocketReceiver(host='0.0.0.0', port=5001)
    receiver.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping receiver...")
        receiver.stop()
        print("Stopped")
