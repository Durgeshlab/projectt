

from flask import Flask, send_from_directory, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/drawing")
def drawing():
    return render_template("drawing.html")

@app.route("/tiles/<path:path>")
def tiles(path):
    return send_from_directory("tiles", path)

@app.route("/web/<path:path>")
def webfiles(path):
    return send_from_directory("web", path)

if __name__ == "__main__":
    app.run(port=5000)
